/** Automatically generated file. DO NOT MODIFY */
package com.cengalabs.flatui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}